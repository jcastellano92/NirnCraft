#version 330 compatibility
// Bloom: the scene's mip chain (Iris builds it for colortex4) above a brightness knee, a few widths summed, so lava,
// fire, lamps, magic and the sun glow; then into colortex0 for final.fsh.
#include "/lib/settings.glsl"

uniform sampler2D colortex4;

in vec2 texcoord;

/*
const bool colortex4MipmapEnabled = true;
*/

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

vec3 knee(vec3 c) {
    float l = max(c.r, max(c.g, c.b));
    return c * smoothstep(1.2, 4.0, l);
}

void main() {
    vec3 c = texture(colortex4, texcoord).rgb;
#ifdef BLOOM
    vec3 b = vec3(0.0);
    b += knee(textureLod(colortex4, texcoord, 2.0).rgb) * 0.35;
    b += knee(textureLod(colortex4, texcoord, 3.5).rgb) * 0.3;
    b += knee(textureLod(colortex4, texcoord, 5.0).rgb) * 0.25;
    b += knee(textureLod(colortex4, texcoord, 6.5).rgb) * 0.2;
    c += b * 0.12;
#endif
    outColor = vec4(c, 1.0);
}
